# Security Specification - ShopSmooth

## Data Invariants
1. A WishlistItem must reference a valid Product ID and be owned by the user.
2. An Alert must have an ownerId matching the authenticated user.
3. User profiles can only be written by the owner (UID match).
4. Product catalog is read-only for public/users, writeable only by system-level processes (simulated for now).
5. Prices in PriceHistory must be positive numbers.

## The Dirty Dozen Payloads

1. **Identity Spoofing**: Attempt to create a user profile for a different UID.
   - Payload: `users/target-uid { "uid": "attacker-uid", "email": "evil@example.com" }`
2. **Account Takeover via Email**: Update a user's email to one that doesn't match the auth token.
3. **Ghost Field Injection**: Add `isAdmin: true` to a user profile.
4. **Wishlist Hijacking**: Add a product to another user's wishlist subcollection.
5. **Alert Tampering**: Update an alert threshold for a different user's alert.
6. **Price Catalog Infiltration**: Attempt to modify a product's price directly in the `products` collection.
7. **Malformed ID**: Use a 2KB string as a product ID to cause storage bloat.
8. **Invalid Price Type**: Set a price to a string `"free"` instead of a number.
9. **History Erasure**: Attempt to delete price history entries.
10. **Self-Assigned Role**: Create a user document with a `role: 'admin'` field.
11. **Negative Threshold Alert**: Set a price drop alert with a threshold of `-100`.
12. **PII Leak**: Attempt to list all users to scrape emails.

## Test Runner Plan
I will implement `firestore.rules` and verify these behaviors.
