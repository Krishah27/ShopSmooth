import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini Initialization
  const geminiApiKey = process.env.GEMINI_API_KEY;
  const ai = geminiApiKey 
    ? new GoogleGenAI({ 
        apiKey: geminiApiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
      }) 
    : null;

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Recommendation engine using Gemini
  app.post("/api/recommendations", async (req, res) => {
    if (!ai) return res.status(500).json({ error: "Gemini API key not configured" });
    
    const { history, preferences } = req.body;
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Based on this browsing history: ${JSON.stringify(history)} and these preferences: ${JSON.stringify(preferences)}, recommend 5 product categories or specific items the user might be interested in. Return as JSON.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                item: { type: Type.STRING },
                reason: { type: Type.STRING },
                category: { type: Type.STRING }
              },
              required: ["item", "reason", "category"]
            }
          }
        }
      });
      
      res.json(JSON.parse(response.text || "[]"));
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to fetch recommendations" });
    }
  });

  // Simulated search API that uses Gemini to "parse" search results 
  // (In a real app, this would hit a scraping service or official APIs)
  app.post("/api/search", async (req, res) => {
     if (!ai) return res.status(500).json({ error: "Gemini API key not configured" });
     const { query } = req.body;

     try {
       const response = await ai.models.generateContent({
         model: "gemini-3-flash-preview",
         contents: `Search query: "${query}". Generate 4 highly realistic mocked search results for e-commerce platforms (Amazon, Flipkart, Myntra, Meesho). Each result should have different prices across these platforms. Include a name, mock image URL (use placeholder.com), and prices. Return as JSON array.`,
         config: {
           responseMimeType: "application/json",
           responseSchema: {
             type: Type.ARRAY,
             items: {
               type: Type.OBJECT,
               properties: {
                 name: { type: Type.STRING },
                 imageUrl: { type: Type.STRING },
                 category: { type: Type.STRING },
                 prices: {
                   type: Type.OBJECT,
                   properties: {
                     amazon: { type: Type.NUMBER },
                     flipkart: { type: Type.NUMBER },
                     myntra: { type: Type.NUMBER },
                     meesho: { type: Type.NUMBER }
                   }
                 }
               }
             }
           }
         }
       });
       res.json(JSON.parse(response.text || "[]"));
     } catch (error) {
       console.error("Search Error:", error);
       res.status(500).json({ error: "Failed to search products" });
     }
  });

  // Help Chat API
  app.post("/api/chat", async (req, res) => {
    if (!ai) return res.status(500).json({ error: "Gemini API key not configured" });
    const { message, history } = req.body;

    try {
      // For @google/genai, we use models.generateContent with history
      const prompt = `You are "Shopie", a cute and helpful shopping assistant for ShopSmooth. 
      ShopSmooth helps users track prices across Amazon, Flipkart, Myntra, and Meesho.
      User message: "${message}"
      Context: ${JSON.stringify(history)}
      Be concise, helpful, and energetic. Use emojis.`;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });

      res.json({ text: result.text || "I'm a bit confused, but I'm still here! ðŸ™‹" });
    } catch (error) {
      console.error("Chat Error:", error);
      res.status(500).json({ error: "Shopie is taking a nap right now." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
