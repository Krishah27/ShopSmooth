import React, { useState, useEffect, createContext, useContext } from 'react';
import { 
  Search, 
  Heart, 
  Bell, 
  TrendingDown, 
  BarChart3, 
  User as UserIcon, 
  ShoppingBag, 
  ChevronRight,
  LogOut,
  AlertCircle,
  Moon,
  Sun,
  Globe,
  MessageCircle,
  X,
  Send,
  Sparkles,
  Settings,
  CreditCard,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  setDoc,
  getDoc,
  serverTimestamp
} from 'firebase/firestore';
import { auth, db, OperationType, handleFirestoreError } from './lib/firebase';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Helper for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Global Context for Settings
type Currency = 'INR' | 'USD' | 'EUR' | 'GBP';
const CurrencySymbols: Record<Currency, string> = {
  INR: '₹',
  USD: '$',
  EUR: '€',
  GBP: '£'
};

const SettingsContext = createContext<{
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  formatPrice: (p: number) => string;
}>({
  theme: 'light',
  toggleTheme: () => {},
  currency: 'INR',
  setCurrency: () => {},
  formatPrice: (p) => `₹${p}`
});

// Pages
enum Page {
  DASHBOARD = 'dashboard',
  WISHLIST = 'wishlist',
  ALERTS = 'alerts',
  SEARCH = 'search',
  PROFILE = 'profile'
}

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>(Page.DASHBOARD);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [currency, setCurrency] = useState<Currency>('INR');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        syncUserProfile(u);
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const formatPrice = (p: number) => {
    const symbol = CurrencySymbols[currency];
    const converted = currency === 'INR' ? p : p * 0.012; 
    return `${symbol}${converted.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  };

  const syncUserProfile = async (u: FirebaseUser) => {
    const userRef = doc(db, 'users', u.uid);
    try {
      const snap = await getDoc(userRef);
      if (!snap.exists()) {
        await setDoc(userRef, {
          uid: u.uid,
          email: u.email,
          createdAt: serverTimestamp(),
          preferences: { categories: [], currency: 'INR', theme: 'light' }
        });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `users/${u.uid}`);
    }
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (e) {
      console.error("Login failed", e);
    }
  };

  const handleLogout = () => signOut(auth);

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <motion.div 
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-indigo-600 font-bold text-2xl"
        >
          ShopSmooth
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 p-4">
        <div className="max-w-md w-full text-center space-y-8 bg-white dark:bg-slate-900 p-12 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl shadow-indigo-100/20">
          <div className="space-y-4">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-6">S</div>
            <h1 className="text-4xl font-black tracking-tight text-slate-900 dark:text-white">
              Shop<span className="text-indigo-600">Smooth</span>
            </h1>
            <p className="text-slate-500 dark:text-slate-400 font-medium">Smart price tracking for Amazon, Flipkart, Myntra, and Meesho.</p>
          </div>
          
          <div className="grid grid-cols-2 gap-3 text-left">
            {[
              { icon: TrendingDown, label: "Tracking", color: "text-indigo-600" },
              { icon: BarChart3, label: "Trends", color: "text-blue-600" },
              { icon: ShoppingBag, label: "Marketplace", color: "text-rose-600" },
              { icon: Bell, label: "Alerts", color: "text-amber-600" }
            ].map((feature, i) => (
              <div key={i} className="p-3 border border-slate-100 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-800/50">
                <feature.icon className={cn("w-4 h-4 mb-1", feature.color)} />
                <h3 className="font-bold text-xs text-slate-800 dark:text-slate-200">{feature.label}</h3>
              </div>
            ))}
          </div>

          <button 
            id="login-button"
            onClick={handleLogin}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
          >
            <UserIcon className="w-5 h-5" />
            Continue with Google
          </button>
        </div>
      </div>
    );
  }

  return (
    <SettingsContext.Provider value={{ theme, toggleTheme, currency, setCurrency, formatPrice }}>
      <div className="h-screen w-screen flex bg-slate-50 dark:bg-slate-950 overflow-hidden font-sans text-slate-900 dark:text-slate-100">
        {/* Sidebar */}
        <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col hidden md:flex">
          <div className="p-8 pb-12">
            <h1 className="text-xl font-bold tracking-tight text-indigo-900 dark:text-indigo-400 flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">S</div>
              ShopSmooth
            </h1>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            <NavItem active={currentPage === Page.DASHBOARD} icon={BarChart3} label="Dashboard" onClick={() => setCurrentPage(Page.DASHBOARD)} />
            <NavItem active={currentPage === Page.SEARCH} icon={Search} label="Search Products" onClick={() => setCurrentPage(Page.SEARCH)} />
            <NavItem active={currentPage === Page.WISHLIST} icon={Heart} label="My Wishlist" onClick={() => setCurrentPage(Page.WISHLIST)} />
            <NavItem active={currentPage === Page.ALERTS} icon={Bell} label="Price Alerts" onClick={() => setCurrentPage(Page.ALERTS)} />
            <NavItem active={currentPage === Page.PROFILE} icon={Settings} label="Settings" onClick={() => setCurrentPage(Page.PROFILE)} />
          </nav>

          <div className="p-4">
            <div className="p-5 bg-slate-900 dark:bg-indigo-950 rounded-2xl text-white">
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mb-1">Savings Goal</p>
              <p className="text-xl font-black mb-3">{formatPrice(14290)}</p>
              <div className="h-1 bg-slate-800 dark:bg-indigo-900 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-2/3"></div>
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <img src={user.photoURL || ''} alt="" className="w-8 h-8 rounded-full border border-slate-200 dark:border-slate-700" />
              <div className="min-w-0 text-[10px]">
                <p className="font-bold text-slate-800 dark:text-slate-200 truncate leading-none mb-1">{user.displayName}</p>
                <button 
                  onClick={handleLogout}
                  className="text-slate-400 hover:text-indigo-600 transition-colors uppercase tracking-widest font-black"
                >
                  Sign Out
                </button>
              </div>
            </div>
            <button onClick={toggleTheme} className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="h-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-8 shrink-0">
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-200 capitalize tracking-tight">{currentPage.replace('-', ' ')}</h2>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-4 relative w-80">
                <Search className="absolute left-3 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Paste link to track price..." 
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full py-2 pl-10 pr-4 text-xs font-medium focus:ring-2 focus:ring-indigo-500/10 outline-none transition-all dark:text-white"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                       setCurrentPage(Page.SEARCH);
                    }
                  }}
                />
              </div>
              <div className="flex -space-x-2">
                <PlatformBadge color="bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-400">AM</PlatformBadge>
                <PlatformBadge color="bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400">FK</PlatformBadge>
                <PlatformBadge color="bg-pink-100 dark:bg-pink-900 text-pink-600 dark:text-pink-400">MY</PlatformBadge>
              </div>
            </div>
          </header>

          {/* Content View */}
          <div className="flex-1 overflow-y-auto p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPage}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.15 }}
              >
                {currentPage === Page.DASHBOARD && <DashboardView user={user} />}
                {currentPage === Page.SEARCH && <SearchView user={user} />}
                {currentPage === Page.WISHLIST && <WishlistView user={user} />}
                {currentPage === Page.ALERTS && <AlertsView user={user} />}
                {currentPage === Page.PROFILE && <ProfileView user={user} />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        {/* AI Bot Shopie */}
        <ShopieBot />
      </div>
    </SettingsContext.Provider>
  );
}

function ShopieBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user'|'assistant', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMsg,
          history: messages.map(m => ({ 
            role: m.role === 'user' ? 'user' : 'model', 
            parts: [{ text: m.text }] 
          }))
        })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'assistant', text: data.text }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', text: 'Oops! Shopie is out for a snack. Try again soon! 🍭' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            className="mb-4 w-80 h-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] shadow-2xl overflow-hidden flex flex-col"
          >
            <div className="p-5 bg-indigo-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm">Shopie</h4>
                  <p className="text-[10px] text-indigo-200 font-medium">Always online & cute</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:rotate-90 transition-transform p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-medium">
              {messages.length === 0 && (
                <div className="text-center py-10 space-y-4">
                   <div className="text-4xl">👋</div>
                   <p className="text-slate-400 font-medium px-4">Hi! I'm Shopie. Need help finding a deal or setting an alert?</p>
                </div>
              )}
              {messages.map((m, i) => (
                <div key={i} className={cn("flex", m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div className={cn(
                    "max-w-[80%] p-3 rounded-2xl",
                    m.role === 'user' 
                      ? "bg-indigo-600 text-white rounded-tr-none" 
                      : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-tl-none"
                  )}>
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-50 dark:bg-slate-800 animate-pulse w-12 h-6 rounded-full" />
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Ask me anything..." 
                className="flex-1 bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-2 text-xs outline-none focus:ring-1 focus:ring-indigo-100 dark:text-white"
              />
              <button 
                onClick={sendMessage}
                disabled={loading}
                className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-indigo-200 dark:shadow-none hover:bg-indigo-700 transition-all border-4 border-white dark:border-slate-800"
      >
        <MessageCircle className="w-8 h-8" />
      </motion.button>
    </div>
  );
}

function ProfileView({ user }: { user: FirebaseUser }) {
  const { theme, toggleTheme, currency, setCurrency } = useContext(SettingsContext);

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10">
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 p-10 flex flex-col items-center text-center">
        <img src={user.photoURL || ''} alt="" className="w-24 h-24 rounded-full border-4 border-indigo-50 dark:border-indigo-950 mb-6" />
        <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100">{user.displayName}</h3>
        <p className="text-slate-400 font-medium mb-8">{user.email}</p>
        
        <div className="w-full h-px bg-slate-100 dark:bg-slate-800 mb-10" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 w-full text-left">
           <section className="space-y-6">
             <div className="flex items-center gap-3">
               <Globe className="w-5 h-5 text-indigo-600" />
               <h4 className="font-bold text-slate-800 dark:text-slate-200">Localization</h4>
             </div>
             
             <div className="space-y-4">
               <div>
                 <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">Display Currency</label>
                 <div className="flex flex-wrap gap-2">
                   {(['INR', 'USD', 'EUR', 'GBP'] as Currency[]).map(c => (
                     <button 
                       key={c}
                       onClick={() => setCurrency(c)}
                       className={cn(
                        "px-6 py-3 rounded-xl font-bold text-xs transition-all border",
                        currency === c 
                          ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100" 
                          : "bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-100 dark:border-slate-700 hover:border-slate-300"
                       )}
                     >
                       {c} {CurrencySymbols[c]}
                     </button>
                   ))}
                 </div>
               </div>
             </div>
           </section>

           <section className="space-y-6">
             <div className="flex items-center gap-3">
               <Sparkles className="w-5 h-5 text-indigo-600" />
               <h4 className="font-bold text-slate-800 dark:text-slate-200">Appearance</h4>
             </div>
             
             <div className="space-y-4">
               <div>
                 <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">System Theme</label>
                 <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => theme === 'dark' && toggleTheme()}
                      className={cn(
                        "p-6 rounded-2xl border flex flex-col items-center gap-3 transition-all",
                        theme === 'light' ? "border-indigo-600 bg-indigo-50/50" : "border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800"
                      )}
                    >
                      <Sun className={cn("w-6 h-6", theme === 'light' ? "text-indigo-600" : "text-slate-400")} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Light</span>
                    </button>
                    <button 
                      onClick={() => theme === 'light' && toggleTheme()}
                      className={cn(
                        "p-6 rounded-2xl border flex flex-col items-center gap-3 transition-all",
                        theme === 'dark' ? "border-indigo-600 bg-indigo-50/50" : "border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800"
                      )}
                    >
                      <Moon className={cn("w-6 h-6", theme === 'dark' ? "text-indigo-600" : "text-slate-400")} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Dark</span>
                    </button>
                 </div>
               </div>
             </div>
           </section>
        </div>

        <div className="w-full mt-12 pt-8 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] text-slate-300">
           <span>Member since May 2026</span>
           <span className="flex items-center gap-2 text-emerald-500"><CreditCard className="w-3 h-3" /> Free Tier</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 flex items-center gap-4">
           <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900 rounded-full flex items-center justify-center text-indigo-600"><Bell className="w-5 h-5" /></div>
           <div><p className="text-xs font-bold text-slate-800 dark:text-slate-200">Push Hub</p><p className="text-[10px] text-slate-400">Manage device tokens</p></div>
         </div>
         <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 flex items-center gap-4">
           <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900 rounded-full flex items-center justify-center text-emerald-600"><Target className="w-5 h-5" /></div>
           <div><p className="text-xs font-bold text-slate-800 dark:text-slate-200">Privacy</p><p className="text-[10px] text-slate-400">Data usage settings</p></div>
         </div>
         <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 flex items-center gap-4">
           <div className="w-10 h-10 bg-amber-50 dark:bg-amber-900 rounded-full flex items-center justify-center text-amber-600"><ShoppingBag className="w-5 h-5" /></div>
           <div><p className="text-xs font-bold text-slate-800 dark:text-slate-200">MarketSync</p><p className="text-[10px] text-slate-400">Linked accounts</p></div>
         </div>
      </div>
    </div>
  );
}

function PlatformBadge({ children, color }: { children: React.ReactNode, color: string }) {
  return (
    <div className={cn("w-7 h-7 rounded-full border-2 border-white dark:border-slate-800 flex items-center justify-center text-[8px] font-bold", color)}>
      {children}
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all font-medium text-sm",
        active 
          ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 shadow-sm" 
          : "text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800"
      )}
    >
      <Icon className={cn("w-4 h-4", active ? "text-indigo-600" : "text-slate-400")} />
      {label}
    </button>
  );
}

// --- Views ---

function DashboardView({ user }: { user: FirebaseUser }) {
  const { formatPrice } = useContext(SettingsContext);
  const [recommendations, setRecommendations] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/recommendations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ history: [], preferences: {} })
    })
    .then(r => r.json())
    .then(data => setRecommendations(data));
  }, []);

  return (
    <div className="space-y-8">
      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Potential Savings" value={formatPrice(4250)} trend="-12%" color="indigo" />
        <StatCard title="Tracked Items" value="12" trend="+2" color="blue" />
        <StatCard title="Active Alerts" value="5" trend="0" color="rose" />
      </div>

      <div className="grid grid-cols-12 gap-8">
        {/* Comparison Header Mockup */}
        <div className="col-span-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 shadow-sm">
           <div className="flex justify-between items-start mb-8">
             <div>
               <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1 rounded-full">Active Tracking</span>
               <h3 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mt-2">Apple iPhone 15 Pro (128GB)</h3>
             </div>
             <div className="px-4 py-1.5 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 text-xs font-bold rounded-full border border-emerald-100 dark:border-emerald-800 flex items-center gap-2">
               <TrendingDown className="w-3 h-3" /> Still Best Price
             </div>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
             <PlatformCard name="Amazon" price={124900} updated="2m ago" color="orange" />
             <PlatformCard name="Flipkart" price={119999} updated="5m ago" color="blue" active />
             <PlatformCard name="Myntra" price={126500} updated="1h ago" color="pink" />
             <PlatformCard name="Meesho" price={123000} updated="12m ago" color="purple" />
           </div>

           <div className="h-32 w-full bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 relative overflow-hidden">
             <div className="flex items-center justify-between mb-2">
               <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">30-Day Trend</span>
               <div className="flex gap-3 text-[10px] font-medium text-slate-400">
                 <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"></span> Flipkart</div>
                 <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300 dark:bg-slate-700"></span> Market Avg</div>
               </div>
             </div>
             <div className="h-full flex items-end gap-1">
               {Array.from({length: 30}).map((_, i) => (
                 <div key={i} className={cn("flex-1 bg-slate-200 dark:bg-slate-700 rounded-t-sm", i === 25 && "bg-indigo-500")} style={{ height: `${Math.random() * 40 + 30}%` }} />
               ))}
             </div>
           </div>
        </div>

        {/* Price Drop Feed */}
        <section className="col-span-12 lg:col-span-8 space-y-4">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">Recent Price Alerts</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recommendations.length > 0 ? (
               recommendations.map((rec, i) => (
                 <div key={i} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-start gap-4 hover:border-indigo-200 transition-colors cursor-pointer group">
                   <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-900/30 transition-colors">
                     <TrendingDown className="w-6 h-6 text-indigo-600" />
                   </div>
                   <div className="min-w-0">
                     <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200 truncate">{rec.item}</h4>
                     <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">{rec.reason}</p>
                     <div className="flex items-center gap-2 mt-3">
                       <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 px-2 py-0.5 rounded uppercase tracking-wider">Dropped {formatPrice(2400)}</span>
                       <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{rec.category}</span>
                     </div>
                   </div>
                 </div>
               ))
            ) : (
              <div className="animate-pulse flex gap-4 w-full">
                <div className="h-24 bg-slate-200 dark:bg-slate-800 rounded-2xl flex-1" />
                <div className="h-24 bg-slate-200 dark:bg-slate-800 rounded-2xl flex-1" />
              </div>
            )}
          </div>
        </section>

        {/* Curated Deals */}
        <section className="col-span-12 lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white space-y-6">
           <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold">Curated Deals</h3>
              <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </div>
           </div>
           <div className="space-y-4">
              {[
                { name: 'Samsung S23 Ultra', price: 74999, drop: '40% OFF', color: 'text-indigo-400' },
                { name: 'Sony XM5', price: 23499, drop: '15% OFF', color: 'text-rose-400' },
                { name: 'MacBook M2', price: 89900, drop: '12% OFF', color: 'text-amber-400' }
              ].map((deal, i) => (
                <div key={i} className="flex items-center gap-4 group cursor-pointer">
                  <div className="w-14 h-14 bg-white/5 rounded-xl border border-white/10 shrink-0 group-hover:scale-110 transition-transform"></div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold truncate">{deal.name}</p>
                    <p className={cn("text-[10px] font-black", deal.color)}>{deal.drop}</p>
                    <p className="text-sm font-black mt-0.5">{formatPrice(deal.price)}</p>
                  </div>
                </div>
              ))}
           </div>
           <button className="w-full py-3 bg-white/10 hover:bg-indigo-600 rounded-xl text-xs font-black uppercase tracking-widest transition-all">View All Premium Deals</button>
        </section>
      </div>
    </div>
  );
}

function PlatformCard({ name, price, updated, color, active }: { name: string, price: number | string, updated: string, color: string, active?: boolean }) {
  const { formatPrice } = useContext(SettingsContext);
  const displayPrice = typeof price === 'number' ? formatPrice(price) : price;
  
  return (
    <div className={cn(
      "p-4 rounded-xl border flex flex-col items-center gap-1 transition-all",
      active 
        ? "border-indigo-500 bg-indigo-50/50 dark:bg-indigo-900/20 ring-4 ring-indigo-500/10" 
        : "border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:bg-white hover:border-slate-300 dark:hover:bg-slate-800 dark:hover:border-slate-600"
    )}>
      <span className={cn("text-[10px] font-black uppercase tracking-widest mb-1", active ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400")}>{name}</span>
      <span className="text-xl font-black text-slate-800 dark:text-slate-100 font-mono tracking-tighter">{displayPrice}</span>
      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{updated}</span>
      <button className={cn(
        "mt-4 w-full py-1.5 text-[10px] font-black rounded uppercase tracking-widest transition-colors",
        active ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-400 hover:text-indigo-600 hover:border-indigo-600"
      )}>
        {active ? 'Best Choice' : 'View Link'}
      </button>
    </div>
  );
}

function StatCard({ title, value, trend, color }: { title: string, value: string, trend: string, color: 'indigo' | 'blue' | 'rose' }) {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 relative overflow-hidden group shadow-sm hover:shadow-md transition-all">
      <p className="text-[#94a3b8] text-[10px] font-extrabold uppercase tracking-[0.2em]">{title}</p>
      <div className="flex items-baseline justify-between group-hover:translate-x-1 transition-transform">
        <h4 className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tight">{value}</h4>
        <div className={cn(
          "px-2.5 py-1 rounded-lg text-[10px] font-black border", 
          trend.startsWith('+') ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border-emerald-100 dark:border-emerald-800' : 
          trend === '0' ? 'bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 border-slate-100 dark:border-slate-700' : 
          'bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 border-rose-100 dark:border-rose-800'
        )}>
          {trend}
        </div>
      </div>
      <div className={cn(
        "h-1 bg-slate-50 dark:bg-slate-800 rounded-full mt-4 overflow-hidden",
      )}>
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: '60%' }}
          className={cn("h-full", color === 'indigo' ? 'bg-indigo-500' : color === 'blue' ? 'bg-blue-500' : 'bg-rose-500')}
        />
      </div>
    </div>
  );
}

function SearchView({ user }: { user: FirebaseUser }) {
  const { formatPrice } = useContext(SettingsContext);
  const [queryInput, setQueryInput] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  const handleSearch = async () => {
    if (!queryInput) return;
    setSearching(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryInput })
      });
      const data = await res.json();
      setResults(data);
    } catch (e) {
      console.error(e);
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="space-y-12">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-12 rounded-[2.5rem] flex flex-col items-center gap-8 relative overflow-hidden shadow-sm">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 dark:bg-indigo-900/10 rounded-bl-full -mr-16 -mt-16 opacity-50" />
        <div className="text-center space-y-2 relative z-10">
          <h1 className="text-4xl font-black text-slate-800 dark:text-slate-100 tracking-tight">Compare Across Every Store</h1>
          <p className="text-slate-400 dark:text-slate-500 font-medium">Instantly find the lowest price on Amazon, Flipkart, Myntra & more.</p>
        </div>
        <div className="w-full max-w-2xl relative flex z-10 shadow-2xl shadow-indigo-100/10">
           <input 
             type="text" 
             value={queryInput}
             onChange={(e) => setQueryInput(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
             placeholder="Search for electronics, fashion, or paste a link..." 
             className="w-full bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-2xl py-6 px-10 outline-none text-lg font-medium focus:border-indigo-600 transition-all placeholder:text-slate-300 dark:placeholder:text-slate-600 dark:text-white shadow-inner"
           />
           <button 
             onClick={handleSearch}
             disabled={searching}
             className="absolute right-3 top-3 bottom-3 bg-indigo-600 px-10 rounded-xl font-black text-white uppercase tracking-widest text-xs hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center gap-2"
           >
             {searching ? 'Scraping...' : <><Search className="w-4 h-4" /> Search</>}
           </button>
        </div>
        <div className="flex gap-6 text-[10px] font-black uppercase tracking-widest text-slate-300 dark:text-slate-600">
           <span>Trending: <span className="text-indigo-400 cursor-pointer" onClick={() => {setQueryInput('iPhone 15 Pro'); handleSearch();}}>iPhone 15 Pro</span></span>
           <span className="text-slate-200 dark:text-slate-800">|</span>
           <span onClick={() => {setQueryInput('Sony XM5'); handleSearch();}} className="cursor-pointer hover:text-indigo-400 transition-colors">Sony XM5</span>
           <span className="text-slate-200 dark:text-slate-800">|</span>
           <span onClick={() => {setQueryInput('Nike Pegasus'); handleSearch();}} className="cursor-pointer hover:text-indigo-400 transition-colors">Nike Pegasus</span>
        </div>
      </div>

      {results.length > 0 && (
        <div className="space-y-6">
          <h3 className="text-xl font-bold tracking-tight px-2 text-slate-800 dark:text-slate-200">Search Results</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
             {results.map((product, i) => (
               <ProductCard key={i} product={product} user={user} />
             ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface ProductCardProps {
  product: any;
  user: FirebaseUser;
  key?: React.Key;
}

function ProductCard({ product, user }: ProductCardProps) {
  const { formatPrice } = useContext(SettingsContext);
  const [saved, setSaved] = useState(false);

  const saveToWishlist = async () => {
    const id = product.name.toLowerCase().replace(/ /g, '-').slice(0, 50);
    const ref = doc(db, 'users', user.uid, 'wishlist', id);
    try {
      await setDoc(ref, {
        productId: id,
        name: product.name,
        prices: product.prices,
        imageUrl: product.imageUrl,
        addedAt: serverTimestamp()
      });
      setSaved(true);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/wishlist/${id}`);
    }
  };

  const platforms = Object.entries(product.prices);
  const minPriceValue = Math.min(...platforms.map(([_, p]) => p as number));
  const minPrice = formatPrice(minPriceValue);

  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col group h-full shadow-sm hover:shadow-xl hover:shadow-indigo-50 dark:hover:shadow-none transition-all border-b-4 border-b-white dark:border-b-slate-900 hover:border-b-indigo-500"
    >
      <div className="aspect-[4/3] bg-slate-50 dark:bg-slate-800 relative overflow-hidden">
        <img 
          src={product.imageUrl?.includes('placeholder') 
            ? `https://placehold.co/400x300/indigo/white?text=${encodeURIComponent(product.name)}` 
            : product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
        />
        <div className="absolute top-4 right-4 flex flex-col gap-2 translate-x-12 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300">
          <button 
            onClick={saveToWishlist}
            className={cn("w-10 h-10 rounded-xl flex items-center justify-center shadow-lg transition-all", saved ? "bg-indigo-600 text-white" : "bg-white dark:bg-slate-700 text-slate-400 hover:text-indigo-600")}
          >
            <Heart className={cn("w-5 h-5", saved && "fill-current")} />
          </button>
          <button className="w-10 h-10 rounded-xl bg-white dark:bg-slate-700 text-slate-400 hover:text-indigo-600 flex items-center justify-center shadow-lg transition-all">
            <Bell className="w-5 h-5" />
          </button>
        </div>
        <div className="absolute bottom-4 left-4">
           <span className="bg-slate-900/80 backdrop-blur-md text-white text-[9px] font-black px-3 py-1.5 rounded-lg uppercase tracking-widest border border-white/10">{minPrice} Best Price</span>
        </div>
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100 mb-5 line-clamp-2 leading-snug">{product.name}</h4>
        
        <div className="space-y-2 flex-1">
          {platforms.map(([platform, price]) => (
            <div key={platform} className={cn("flex items-center justify-between text-[10px] px-3 py-2 rounded-lg border transition-colors", price === minPriceValue ? "bg-indigo-50 dark:bg-indigo-900/30 border-indigo-100 dark:border-indigo-800 font-bold text-indigo-700 dark:text-indigo-400" : "border-slate-50 dark:border-slate-800 text-slate-400 hover:border-slate-200 dark:hover:border-slate-700")}>
              <span className="capitalize">{platform}</span>
              <span className="font-mono">{formatPrice(price as number)}</span>
            </div>
          ))}
        </div>

        <button className="w-full mt-6 py-3 bg-slate-50 dark:bg-slate-800 text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
          Price Insights
        </button>
      </div>
    </motion.div>
  );
}

function WishlistView({ user }: { user: FirebaseUser }) {
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'users', user.uid, 'wishlist'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (e) => handleFirestoreError(e, OperationType.LIST, `users/${user.uid}/wishlist`));
    return () => unsubscribe();
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between px-2">
         <h3 className="text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight">Saved Items</h3>
         <div className="flex items-center gap-2">
           <span className="text-xs font-bold text-slate-400 uppercase tracking-widest bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">{items.length} trackings</span>
         </div>
      </div>
      {items.length === 0 ? (
        <div className="py-24 flex flex-col items-center text-center space-y-6 bg-slate-50/50 dark:bg-slate-800/20 rounded-[3rem] border border-dashed border-slate-200 dark:border-slate-800">
          <div className="w-20 h-20 bg-white dark:bg-slate-900 rounded-[2rem] flex items-center justify-center shadow-lg text-slate-100 dark:text-slate-800 border border-slate-50 dark:border-slate-800 translate-y-4 opacity-50">
            <Heart className="w-10 h-10" />
          </div>
          <div className="space-y-2 max-w-sm">
            <h4 className="font-black text-xl text-slate-800 dark:text-slate-200 tracking-tight">Your wishlist is empty</h4>
            <p className="text-slate-400 text-sm font-medium">Search for products and tap the heart icon to start tracking prices across stores.</p>
          </div>
          <button className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">Explore Market</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, i) => (
            <ProductCard key={i} product={item} user={user} />
          ))}
        </div>
      )}
    </div>
  );
}

function AlertsView({ user }: { user: FirebaseUser }) {
  return (
    <div className="max-w-4xl mx-auto py-12 space-y-12">
      <div className="text-center space-y-3">
        <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
          <Bell className="w-8 h-8" />
        </div>
        <h3 className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tight">Price Monitoring</h3>
        <p className="text-slate-400 font-medium max-w-md mx-auto">Configure smart alerts and get notified before the good deals disappear.</p>
      </div>
      
      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="p-10 border-b border-slate-100 dark:border-slate-800 flex items-center gap-6">
           <div className="bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 p-4 rounded-2xl shadow-inner">
             <AlertCircle className="w-8 h-8" />
           </div>
           <div className="flex-1">
             <h4 className="font-bold text-slate-800 dark:text-slate-200">Push Notifications</h4>
             <p className="text-xs text-slate-400 mt-1 font-medium">Enable real-time tracking alerts on your mobile device or browser.</p>
           </div>
           <button className="bg-slate-900 dark:bg-indigo-600 text-white px-8 py-3.5 rounded-xl text-xs font-black uppercase tracking-[0.2em] hover:bg-slate-800 dark:hover:bg-indigo-700 transition-all shadow-lg">Activate</button>
        </div>
        
        <div className="p-20 text-center space-y-4 bg-slate-50/20 dark:bg-slate-800/10">
           <div className="text-slate-200 dark:text-slate-700 uppercase text-[10px] font-black tracking-[0.5em]">System Idle</div>
           <p className="text-slate-300 dark:text-slate-600 italic text-sm">No active price drop triggers detected for your wishlist items.</p>
        </div>
      </div>
    </div>
  );
}
